package com.kotlin.classstudy.enumc

enum class State {
    NORMAL,NO_DATA,NO_INTERNET,ERROR,OTHER
}