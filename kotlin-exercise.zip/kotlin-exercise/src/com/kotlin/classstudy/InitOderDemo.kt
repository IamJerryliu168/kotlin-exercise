package com.kotlin.classstudy

class InitOderDemo constructor(name: String) {

    val firstProperty = "First property : $name".also(::println)

    init {
        println("First initializer block that prints ${name}")
    }

    val secondProperty = "Second property : ${name.length}".also(::println)

    init {
        println("Second initializer block that prints ${name.length}")
    }


    constructor(i: Int) : this(name = "abc"){
        println("Constructor $i")
    }


    fun add(a:Int, b:Int) : Int {
        return a + b;
    }

}