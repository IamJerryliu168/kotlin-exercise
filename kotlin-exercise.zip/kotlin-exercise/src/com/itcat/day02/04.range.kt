package com.itcat.day02


fun main() {

    val range1: IntRange = 1..10
    val range2 = 1.rangeTo(10)
    val range3 = IntRange(1,10)

    val range4: CharRange = 'a'..'z'
    val range5 = 'a'.rangeTo('z')
    var range6 = CharRange('a','z')

    val range7: LongRange = 1L..8L
    val range8 = LongRange(1L,8L)
    val range9 = 1L.rangeTo(8L)


    for(char in range4){
        println(char)
    }


    /*
    for(i in 5 downTo 1) {

    }
    */

    for(i in 1 until 10) {
        // i in [1, 10) 排除了 10
        println(i)
    }

    for((index, i) in range1.withIndex()){
        println("index=$index i=$i")
    }

    range7.forEach{
        println(it)
    }

    range4.forEachIndexed { index:Int, c:Char ->
        println("index=$index c=$c")
    }


    /******************************反向区间********************************/
    val rang10:IntProgression = 10 downTo 1
    rang10.forEach{
        println(it)
    }

    /******************************区间反转*******************************/

    val range11:IntProgression = range1.reversed()
    for(i:Int in range11 step 2) {
        println(i)
    }

}