import com.kotlin.classstudy.Derived
import com.kotlin.classstudy.InitOderDemo
import com.kotlin.classstudy.MapUsing

fun main(args: Array<String>) {

    val customer = Customer("first");

    println("Hello World!" + customer.getName())

    val initOderDemo = InitOderDemo(8);

    println(initOderDemo.add(2,10))

    var derived = Derived("test")

    println(derived.multi(2,8))


    val mapUsing = MapUsing();
    mapUsing.mapOfUsing();

    mapUsing.collectionFoldUsing();

    (mapUsing::collectionFoldUsingString)()
}