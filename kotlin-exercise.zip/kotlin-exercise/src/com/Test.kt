package com

import java.time.LocalDate

fun main() {
    val monthStr = "${LocalDate.now().year}-${LocalDate.now().withMonth(10).monthValue}"
    println(monthStr)

    val monthStartDate = LocalDate.now().withMonth(10).withDayOfMonth(1).minusMonths(1)
    println(monthStartDate)

    val month = "${LocalDate.now().year}-${LocalDate.now().monthValue}"
    println(month)

    val monthStartDate2 = LocalDate.now().withDayOfMonth(1).minusMonths(1)
    println(monthStartDate2)

    val dayOfMonth = LocalDate.now().dayOfMonth
    println(dayOfMonth)
}