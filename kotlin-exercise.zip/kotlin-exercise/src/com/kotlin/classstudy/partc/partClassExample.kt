package com.kotlin.classstudy.partc


class Other {
    val otherNumber = 1

    fun partMethod() {
        var name : String = "part Method"

        class Part {
            var numPart : Int = 2;

            fun test() {
                name = "test";

                numPart = 5;

                println("这是局部类中的方法")
            }

        }

        var part = Part()

        println("name = $name \t numPart = " + part.numPart )

        part.test()

        println("name = $name \t numPart = " + part.numPart)
    }
}

fun main(args : Array<String>) {
    Other().partMethod()
}