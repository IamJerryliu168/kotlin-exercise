package com.kotlin.classstudy.enumc

enum class Color(var argb : Int) {
    RED(1),
    WHITE(2),
    BLACK(3),
    GREEN(4)
}