package com.itcat.day02


fun main(args: Array<String>) {

    var account: Int = 10
    var number: Int = 5

    while(account >= 0) {
        println(account);
        account--;
    }

    do{
        println(number);
        number--;
    } while (number > 5)

}