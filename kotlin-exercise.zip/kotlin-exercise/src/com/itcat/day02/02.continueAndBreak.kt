package com.itcat.day02


/*
   continue 和 break 只能用在for 循环里, 不能用在forEach
 */
fun main(args : Array<String>) {

    println("--------1:break----------")

    val str : String = "abcdefg"

    for(c: Char in str){
        if(c == 'd'){
            break
        }
        println(c)
    }

    println("--------2:continue----------")

    for(c: Char in str){
        if(c == 'd'){
            continue
        }
        println(c)
    }


    println("-------3:标签限定 break 开始----------")

    loop@ for(i in 1..10){
        for (j in 1..5){
            println("i=$i,j=$j")
            if(j == 2){
                break@loop
            }
        }
    }
    println("---------3:标签限定 break 结束----------")

    println("---------4:标签限定 continue 开始----------")

    loop@ for(i in 1..10){
        for (j in 1..5){
            println("i=$i,j=$j")
            if(j == 2){
                continue@loop
            }
        }
    }
    println("---------4:标签限定 continue 结束----------")

    println("---------5:标签处返回 开始----------")


    println("---------5:标签处返回 结束----------")
}

// 全局返回
fun foo() {
    listOf<Int>(1,2,3,4,5).forEach<Int> {
        if(it==3) {
            return   // ⾮局部直接返回到 foo() 的调⽤者
        }
        println(it)
    }
    println("this point is unreachable")
}

// 局部返回1
fun foo2() {
    listOf(1,2,3,4,5).forEach lit@ {
        if (it == 3) {
            return@lit  //局部返回到该 lambda 表达式的调⽤者，即 forEach 循环
        }
        println(it)
    }
    print(" done with explicit label")
}

// 局部返回2
fun foo3() {
    listOf(1,2,3,4,5).forEach{
        if (it == 3) {
            return@forEach  //隐式标签 效果同 foo2
        }
        println(it)
    }
    print(" done with implicit label")
}

// 局部返回3
// 或者，我们⽤⼀个匿名函数替代 lambda 表达式。 匿名函数内部的 return 语句将从该匿名函数⾃⾝返回
fun foo4() {
    listOf(1,2,3,4,5).forEach(fun(value : Int) {
        if(value == 3) {
            return
        }
        println(value)
    })
    print(" done with anonymous function")
}

//请注意，前面几个⽰例中使⽤的局部返回类似于在常规循环中使⽤ continue。并没有 break 的直接
//等价形式，不过可以通过增加另⼀层嵌套 lambda 表达式并从其中⾮局部返回来模拟：

fun foo5() {
    run loop@{
        listOf(1,2,3,4,5).forEach {
            if(it == 3) {
                return@loop  //从传⼊ run 的 lambda 表达式⾮局部返回
            }
            println(it)
        }
        print(" done with nested loop")
    }
}




