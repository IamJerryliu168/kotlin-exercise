package com.itcat.day02

import com.sun.xml.internal.fastinfoset.util.StringArray


fun main() {
    val array1: Array<Int> = arrayOf(1,2,3,4)

    var array2 = Array(5) {
        i -> (i * i).toString()
    }

    // IntArray  CharArray BooleanArray
    var array3: StringArray = StringArray(5,10,false)
    array3.add("a")
    array3.add("b")
    array3.add("c")
    array3.add("d")
    array3.add("e")

    array1.forEach {
        println(it)
    }

    for(str:String in array2){
        println(str)
    }

    var array4: Array<Any> = arrayOf("张三",10,'a')


    /******************************数组元素修改**************************************/
    var array5 = arrayOf(1,2,3,4,5)
    array5[0] = 20
    array5.set(2,10)


    /******************************数组元素角标的查找**************************************/
    var array6 = arrayOf("张三","李四","王五","刘六","张三")
    var index1:Int = array6.indexOf("张三")
    println(index1)
    var index2:Int = array6.lastIndexOf("张三")
    println(index2)
    var index3:Int= array6.indexOfFirst {
        it.startsWith("张")
    }
    println(index3)
    var index4:Int = array6.indexOfLast {
        it.startsWith("张")
    }
    println(index4)
}