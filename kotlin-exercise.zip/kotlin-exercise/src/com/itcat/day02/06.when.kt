package com.itcat.day02

fun main() {

    println(whenExpress1(10))

    println(hasPrefix("China!!"))

    println(hasPrefix("prefix_China!!"))


    noParameter(7)
}


fun whenExpress1(age: Int): String {

    when(age) {
        10 -> {
            return "正在上小学"
        }
        12 -> {
            return "正在上初中"
        }
        17 -> {
            return "正在上高中"
        }
        20 -> {
            return "正在上大学"
        }
        else -> {
            return "社会大学"
        }
    }
}

fun whenExpress2(age: Int): String {
    when(age) {
        4,5,6,7,8,9,10,11 -> {
            return "正在上小学"
        }
        in 12..15 -> {
            return "正在上初中"
        }
        in 16..18 -> {
            return "高中"
        }
        in 18..20 -> {
            return "大学"
        }
        !in 4..20 -> {
            return "社会大学"
        }
        else -> {
            return "其它"
        }
    }
}


fun hasPrefix(x: Any) = when(x) {
    is String -> x.startsWith("prefix")
    else -> false
}


fun noParameter(age: Int) = when {
    age == 7 -> {
        println("age is 7")
    }
    else -> {
        println("age is not 7")
    }
}


/**
 * 必须有2个或以上的大写字母
 * 2个或以上的小写字母
 * 3个或以上的数字
 */
fun parse(pwd: String): Boolean {
    if (pwd.length < 3 || pwd.length > 20) return false

    val upChar:CharRange = 'A'..'Z'
    val lowChar:CharRange = 'a'..'z'
    val intRange:CharRange = '0'..'9'

    var intCount = 0
    var upCount = 0
    var lowCount = 0

    pwd.forEach {
        when(it) {
            in upChar -> {
                upCount++
            }
            in lowChar -> {
                lowCount++
            }
            in intRange -> {
                intCount++
            }
            '_' -> {

            }
            else -> {
                return false
            }
        }
    }

    if(upCount >= 2 && lowCount >= 2 && intCount >= 3 ) {
        return true
    }
    return false
}