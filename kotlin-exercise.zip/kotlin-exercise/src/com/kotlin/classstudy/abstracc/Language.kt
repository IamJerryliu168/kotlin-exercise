package com.kotlin.classstudy.abstracc


open class Base {
    open fun init() {

    }
}


abstract  class Language : Base() {
    val TAG = this.javaClass.simpleName

    fun test() : Unit {

    }

    abstract var name : String

    abstract override fun init()

}

class TestAbstractA : Language() {

    override var name : String
        get() = "Kotlin"
        set(value) {}

    override fun init() {
        println("我是  $name")
    }
}

class TestAvstractB : Language() {

    override var name : String
    get() = "Java"
    set(value) {}

    override fun init() {
        println("我是 $name")
    }

}

fun main(args : Array<String>) {

    val testA = TestAbstractA()

    val testB = TestAvstractB()

    println(testA.name)
    testA.init()

    println(testB.name)
    testB.init()


}