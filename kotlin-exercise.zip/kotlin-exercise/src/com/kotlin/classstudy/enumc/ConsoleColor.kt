package com.kotlin.classstudy.enumc


fun main(args: Array<String>) {
    ConsoleColor.RED.print()
    println(ConsoleColor.RED.name)
    println(ConsoleColor.RED.ordinal)
    println(ConsoleColor.WHITE.ordinal)

    println(enumValues<ConsoleColor>().joinToString { it.name })


    println(ConsoleColor.values()[1])
}


enum class ConsoleColor(var argb : Int) {

    RED(1) {
        override fun print() {
            println("我是枚举常量RED")
        }
    },
    WHITE(2){
        override fun print() {
            println("我是枚举常量WHITE")
        }
    },
    BLACK(3){
        override fun print() {
            println("我是枚举常量BLACK")
        }
    },
    GREEN(4) {
        override fun print() {
            println("我是枚举常量GREEN")
        }
    };

    abstract fun print()
}