package com.kotlin.basicgrammer


/**
 *   page 78
 */

fun comapre1(a: Int, b: Int) : Int {

    val max = if(a >= b) a else b

    return max;
}

fun compare2(a: Int, b: Int) : Int {
    var max : Int;
    if(a >= b) {
        max = a;
    } else {
        max = b;
    }

    return max;
}


fun main(args: Array<String>) {
    val a:Int = 1;
    val b:Int = 2;
    var max = comapre1(a, b);

    print("Ivoking compare1   >>  the max is ${max}");

    max = compare2(5, 6);
    print("Ivoking compare2   >>  the max is ${max}");

}