package com.itcat.day02


fun main(args: Array<String>) {
    val str = "abcde"

    for (a in str) {
        println(a)
    }

    // 如果你想要通过索引遍历⼀个数组或者⼀个 list
    val x: IntArray = intArrayOf(100,101,102)
    for(i in x.indices){
        println(x[i])
    }

    for((index, c) in str.withIndex()) {
        println("index = $index ; c = $c")
    }

    str.forEach {
        println(it)
    }

    str.forEachIndexed { index: Int, c: Char ->
        println("index = $index , c = $c")
    }

    // 对区间或者数组的 for 循环会被编译为并不创建迭代器的基于索引的循环
    for(i in 1..3) {
        println(i)
    }
    println("----------------------")
    for(i in 6 downTo 0 step 2){
        println(i)
    }
}