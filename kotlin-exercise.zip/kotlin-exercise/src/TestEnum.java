public class TestEnum {
    private enum Money {
        HUNDRED, FIFTY, TWENTY, TEN, FIVE, TWO, ONE
    }

    public static void main(String[] args) {
        for (Money m : Money.values()) {
            System.out.print(m + ":" + m.ordinal() + " ");
            switch (m) {
                case HUNDRED:
                    System.out.println("$" + 100);
                    break;
                case FIFTY:
                    System.out.println("$" + 50);
                    break;
                case TWENTY:
                    System.out.println("$" + 20);
                    break;
                case TEN:
                    System.out.println("$" + 10);
                    break;
                case FIVE:
                    System.out.println("$" + 5);
                    break;
                case TWO:
                    System.out.println("$" + 2);
                    break;
                case ONE:
                    System.out.println("$" + 1);
                    break;
                default:
                    break;
            }
        }
        System.out.println();
    }
}
