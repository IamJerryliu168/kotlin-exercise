package com.kotlin.classandobject

/*
     a:  类声明由类名、类头（指定其类型参数、主构造函数等）以及由花括号包围的类体构成
     b:  构造函数 （主构造函数及 次构造函数，constructor 关键字），初始化块
     c:  次构造函数委托主构造函数

 */
