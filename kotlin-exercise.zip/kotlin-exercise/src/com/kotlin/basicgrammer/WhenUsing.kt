package com.kotlin.basicgrammer


/*
 a:当做表达式
 b:多个分⽀条件放在⼀起
 c:⽤任意表达式（⽽不只是常量）作为分⽀条件
 d:可以检测⼀个值在（in）或者不在（!in）⼀个区间或者集合中
 e:检测⼀个值是（is）或者不是（!is）⼀个特定类型的值
 f:when 也可以⽤来取代 if-else if链。 如果不提供参数，所有的分⽀条件都是简单的布尔表达式，⽽当⼀个分⽀的条件为真时则执⾏该分⽀
 g: it is possible to capture when subject in a variable
 */


fun usinWhen1(num : Int) {

    when(num) {
        1 -> print("num == 1")
        2 -> print("num==2")
        else -> {
            print("num is neither 1 or 2")
        }
    }

}


fun usingWhen2(str : String) {

}

