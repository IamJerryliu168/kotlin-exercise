package com.kotlin.classstudy

class MapUsing {

    fun mapOfUsing() {
        var maps : Map<String, String>;

        maps = mapOf("data" to "{\"key\":\"This is a test.\"}", "version" to "1.2", "accountId" to "rerrfdfsewqe4566sdd");

        println(maps.get("data"));
    }

    /*
        acc =  0, i = 1,result = 1
        acc =  1, i = 2,result = 3
        acc =  3, i = 3,result = 6
        acc =  6, i = 4,result = 10
        acc =  10, i = 5,result = 15
     */
    fun collectionFoldUsing() {
        var items = listOf(1,2,3,4,5)
        items.fold(0, {
            acc: Int, i:Int -> print("acc =  $acc, i = $i,")
            val result = acc + i
            println("result = $result")
            result
        })
    }

    /*
    Elements: 1 2 3 4 5 && 120
     */
    fun collectionFoldUsingString() {
        var items = listOf(1,2,3,4,5)
        val joinedToString = items.fold("Elements:", { acc, i -> acc + " " + i })

        val product = items.fold(1, Int::times)

        println("$joinedToString && $product")
    }
}