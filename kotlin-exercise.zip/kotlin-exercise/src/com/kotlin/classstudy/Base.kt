package com.kotlin.classstudy

open class Base(p: Int) {

    init {
        println("This is the Base class $p")
    }

    constructor(name: String) : this(p = 0) {
        println("sub constructor $name")
    }

    open fun  multi(a:Int, b:Int) : Int {
        return a * b;
    }



}