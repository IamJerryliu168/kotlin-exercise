package com.kotlin.classstudy

class Derived(p: Int) : Base(p)  {

    init {
        println("This is the intiliazer block for  extend class Derived!")
    }

    constructor(name: String) : this(7) {
        println("sub constructor in Derived.")
    }

    override fun multi(a: Int, b: Int): Int {
        println("to override the multi method in Base class")
        return super.multi(a, b)
    }
}