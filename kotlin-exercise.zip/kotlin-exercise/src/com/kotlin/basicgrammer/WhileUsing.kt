package com.kotlin.basicgrammer

/*

    while  and do...while
 */