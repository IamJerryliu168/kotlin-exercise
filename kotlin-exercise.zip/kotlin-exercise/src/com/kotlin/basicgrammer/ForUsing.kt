package com.kotlin.basicgrammer


/*

a:  在数字区间上迭代
b:  要通过索引遍历⼀个数组或者⼀个 list   array.indices
c:  ⽤库函数 withIndex

 */