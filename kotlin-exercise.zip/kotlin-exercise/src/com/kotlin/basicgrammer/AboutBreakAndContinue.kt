package com.kotlin.basicgrammer

/*

  a:  返回和跳转    return  break  continue

  b: 标签

  c: 标签处返回

 */