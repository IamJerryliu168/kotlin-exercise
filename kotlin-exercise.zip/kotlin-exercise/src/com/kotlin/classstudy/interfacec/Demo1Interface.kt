package com.kotlin.classstudy.interfacec

fun main(args: Array<String>) {

    var demo = Demo1()

    demo.fun1()
}


interface Demo1Interface {
    fun fun1()
}

class Demo1 : Demo1Interface {

    override fun fun1() {
        println("我是接口中的fun1方法")
    }

}